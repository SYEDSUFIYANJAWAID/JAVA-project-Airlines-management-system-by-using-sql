/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airline.management.system;
import java.sql.*;
public class connection {
    Connection c;
    Statement s;
    public connection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://sql5.freemysqlhosting.net/sql5755803","sql5755803","wRpJX9pLK5");
            s=c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


