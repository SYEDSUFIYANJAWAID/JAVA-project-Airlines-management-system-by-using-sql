/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airline.management.system;

import java.util.Stack;
import javax.swing.table.DefaultTableModel;



public class flightsinfo extends javax.swing.JFrame {

    private Stack<String[]> flight; // Stack to hold flight information

    /**
     * Creates new form Flightinfo
     */
    public flightsinfo() {
        initComponents();
        flight = new Stack<>(); // Initialize the stack

        // Dummy data for flights
        String[][] dummyFlights = {
            {"FL001", "Flight One", "New York", "Los Angeles"},
            {"FL002", "Flight Two", "Chicago", "Miami"},
            {"FL003", "Flight Three", "San Francisco", "Seattle"},
            {"FL004", "Flight Four", "Houston", "Denver"}
        };

        // Add dummy data to the stack and table
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        for (String[] flightData : dummyFlights) {
            flight.push(flightData); // Push data onto the stack
            model.addRow(flightData); // Add data to the table
        }
    }

    /**
     * Method to display the top entry of the stack
     */
    public void displayTopFlight() {
        if (!flight.isEmpty()) {
            String[] topFlight = flight.peek(); // Peek at the top of the stack
            System.out.println("Top Flight in Stack:");
            for (String detail : topFlight) {
                System.out.print(detail + " ");
            }
            System.out.println();
        } else {
            System.out.println("The stack is empty.");
        }
    }

    /**
     * Method to remove the top entry from the stack
     */
    public void removeTopFlight() {
    if (!flight.isEmpty()) {
        String[] removedFlight = flight.pop();
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear table
        for (String[] f : flight) {
            model.addRow(f); // Repopulate table with remaining stack data
        }
        System.out.println("Removed Flight: " + String.join(", ", removedFlight));
    } else {
        System.out.println("The stack is empty.");
    }
}


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new flightsinfo().setVisible(true);
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     */
    @SuppressWarnings("unchecked")
    private void initComponents() {
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        displayButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object[][] {},
            new String[] {
                "Flight Code", "Flight Name", "Source", "Destination"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 51, 51));
        jButton1.setText("DONE");
        jButton1.addActionListener(evt -> {
            setVisible(false);
            // Redirect to dashboard or other functionality
            System.out.println("Exiting Flight Info.");
        });

        displayButton.setText("Display Top Flight");
        displayButton.addActionListener(evt -> displayTopFlight());

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 760, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(100, 100, 100)
                .addComponent(displayButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 400, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(100, 100, 100))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(displayButton))
                .addGap(0, 10, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 800, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }

    // Variables declaration
    private javax.swing.JButton displayButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration
}
 
