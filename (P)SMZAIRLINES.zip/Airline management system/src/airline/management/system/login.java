/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airline.management.system;


public class login {
    
     public static void main(String[]args){
      NewJFrame loginFrame=new NewJFrame();
      loginFrame.setVisible(true);
      loginFrame.pack();
      loginFrame.setLocationRelativeTo(null);
      
     }
}
