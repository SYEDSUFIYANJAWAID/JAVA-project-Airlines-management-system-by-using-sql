/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package airline.management.system;
import java.sql.*;
import com.toedter.calendar.JDateChooser;
import javax.swing.JOptionPane;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.util.*;

public class flightbooking extends javax.swing.JFrame {
JDateChooser dcdate;
    
    public flightbooking() {
        initComponents();
    
try {
                connection c = new connection();
                String query = "select * from flight";
                ResultSet rs=c.s.executeQuery(query);
                
                while(rs.next()){
                    source.add(rs.getString("SOURCE"));
                    destination.add(rs.getString("DESTINATION"));
                }
    }
    catch(Exception e){
                e.printStackTrace();
                
               
    }
dcdate = new JDateChooser();
dcdate.setBounds(318,580,200,30);
add(dcdate);

    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jlable2 = new javax.swing.JLabel();
        jlable3 = new javax.swing.JLabel();
        jlable4 = new javax.swing.JLabel();
        jlable6 = new javax.swing.JLabel();
        nic = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        bookFlight = new javax.swing.JButton();
        source = new java.awt.Choice();
        destination = new java.awt.Choice();
        flightCode = new javax.swing.JLabel();
        flightnumber = new javax.swing.JLabel();
        jdatechosser = new javax.swing.JLabel();
        searchFlight = new javax.swing.JButton();
        jlable1 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        nationality = new javax.swing.JTextField();
        address = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        gender = new javax.swing.JTextField();
        flightcode = new javax.swing.JTextField();
        FLIGHT_NUMBER = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        dtime = new javax.swing.JTextField();
        atime = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setMinimumSize(new java.awt.Dimension(800, 600));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(0, 51, 51));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(910, 600));

        jLabel1.setBackground(new java.awt.Color(0, 51, 51));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BOOK FLIGHT");

        jLabel2.setBackground(new java.awt.Color(0, 51, 51));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("NIC NUMBER");

        jlable2.setBackground(new java.awt.Color(0, 51, 51));
        jlable2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jlable2.setForeground(new java.awt.Color(255, 255, 255));
        jlable2.setText("NATIONALITY");

        jlable3.setBackground(new java.awt.Color(0, 51, 51));
        jlable3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jlable3.setForeground(new java.awt.Color(255, 255, 255));
        jlable3.setText("ADDRESS");

        jlable4.setBackground(new java.awt.Color(0, 51, 51));
        jlable4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jlable4.setForeground(new java.awt.Color(255, 255, 255));
        jlable4.setText("PHONE NUMBER");

        jlable6.setBackground(new java.awt.Color(0, 51, 51));
        jlable6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jlable6.setForeground(new java.awt.Color(255, 255, 255));
        jlable6.setText("GENDER");

        nic.setBackground(new java.awt.Color(255, 255, 255));
        nic.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nic.setForeground(new java.awt.Color(0, 0, 0));

        search.setBackground(new java.awt.Color(255, 255, 255));
        search.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        search.setForeground(new java.awt.Color(0, 51, 51));
        search.setText("SEARCH");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(0, 51, 51));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("SOURCE");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("DESTINATION");

        bookFlight.setBackground(new java.awt.Color(0, 51, 51));
        bookFlight.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        bookFlight.setForeground(new java.awt.Color(255, 255, 255));
        bookFlight.setText("BOOK FLIGHT");
        bookFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookFlightActionPerformed(evt);
            }
        });

        source.setBackground(new java.awt.Color(0, 51, 51));
        source.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N

        destination.setBackground(new java.awt.Color(0, 51, 51));
        destination.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N

        flightCode.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        flightCode.setForeground(new java.awt.Color(255, 255, 255));
        flightCode.setText("FLIGHT CODE");

        flightnumber.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        flightnumber.setForeground(new java.awt.Color(255, 255, 255));
        flightnumber.setText("FLIGHT NUMBER");

        jdatechosser.setBackground(new java.awt.Color(0, 51, 51));
        jdatechosser.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jdatechosser.setForeground(new java.awt.Color(255, 255, 255));
        jdatechosser.setText("DATE OF TRAVEL");

        searchFlight.setBackground(new java.awt.Color(255, 255, 255));
        searchFlight.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        searchFlight.setForeground(new java.awt.Color(0, 51, 51));
        searchFlight.setText("SEARCH FLIGHTS");
        searchFlight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchFlightActionPerformed(evt);
            }
        });

        jlable1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jlable1.setForeground(new java.awt.Color(255, 255, 255));
        jlable1.setText("NAME");

        name.setBackground(new java.awt.Color(255, 255, 255));
        name.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name.setForeground(new java.awt.Color(0, 51, 51));

        nationality.setBackground(new java.awt.Color(255, 255, 255));
        nationality.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        nationality.setForeground(new java.awt.Color(0, 51, 51));

        address.setBackground(new java.awt.Color(255, 255, 255));
        address.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        address.setForeground(new java.awt.Color(0, 51, 51));

        phone.setBackground(new java.awt.Color(255, 255, 255));
        phone.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phone.setForeground(new java.awt.Color(0, 51, 51));
        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });

        gender.setBackground(new java.awt.Color(255, 255, 255));
        gender.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        gender.setForeground(new java.awt.Color(0, 51, 51));

        flightcode.setBackground(new java.awt.Color(255, 255, 255));
        flightcode.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        flightcode.setForeground(new java.awt.Color(0, 51, 51));

        FLIGHT_NUMBER.setBackground(new java.awt.Color(255, 255, 255));
        FLIGHT_NUMBER.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        FLIGHT_NUMBER.setForeground(new java.awt.Color(0, 51, 51));
        FLIGHT_NUMBER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FLIGHT_NUMBERActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("DEPARTURE TIME");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ARRIVAL TIME");

        dtime.setBackground(new java.awt.Color(255, 255, 255));
        dtime.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        atime.setBackground(new java.awt.Color(255, 255, 255));
        atime.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/bookflight2.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(299, 299, 299)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jlable2)
                            .addComponent(jlable1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jlable3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(38, 38, 38)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(name, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE)
                                    .addComponent(nic, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(32, 32, 32)
                                .addComponent(search, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(nationality, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(246, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(151, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jlable6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jlable4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(426, 426, 426))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bookFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 678, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jdatechosser)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8)
                                            .addComponent(jLabel7)
                                            .addComponent(flightCode, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(38, 38, 38))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(flightnumber)
                                        .addGap(19, 19, 19))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(destination, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(FLIGHT_NUMBER, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(flightcode, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(searchFlight))
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(dtime, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(33, 33, 33)
                                            .addComponent(jLabel4)
                                            .addGap(18, 18, 18)
                                            .addComponent(atime)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(source, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(76, 76, 76)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(121, 121, 121))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(search))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlable1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlable2)
                            .addComponent(nationality, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jlable3, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jlable6)
                                .addGap(3, 3, 3))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlable4)
                            .addComponent(phone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(source, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(destination, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(flightCode, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(flightcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(flightnumber, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(FLIGHT_NUMBER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(atime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addComponent(jdatechosser, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bookFlight, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(150, 150, 150))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 980, 710);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 978, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed

        // TODO add your handling code here:
      
    if(evt.getSource()==search){
       String nic1 = nic.getText();
        try {
                connection c = new connection();
                String query = "select * from passenger where nic ='"+nic1+"'";              
                ResultSet rs=c.s.executeQuery(query);
                if(rs.next()){
                     name.setText(rs.getString("name"));
                     nationality.setText(rs.getString("nationality"));
             address.setText(rs.getString("Address"));
                     phone.setText(rs.getString("phone"));
                     gender.setText(rs.getString("gender"));
     
                
             }else{
                 JOptionPane.showMessageDialog(rootPane, "NO USER EXIST");
             }
             
    }
    catch(Exception e){
                e.printStackTrace();
                
               
    }
        
   }
   
    }//GEN-LAST:event_searchActionPerformed

    private void FLIGHT_NUMBERActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FLIGHT_NUMBERActionPerformed
       
    }//GEN-LAST:event_FLIGHT_NUMBERActionPerformed

    private void searchFlightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFlightActionPerformed
       if(evt.getSource()==searchFlight){
       String src = source.getSelectedItem();
       String dest = destination.getSelectedItem();
        try {
                connection c = new connection();
                String query = "select * from flight where SOURCE ='"+src+"' and DESTINATION ='"+dest+"'"; ; 
                
                ResultSet rs=c.s.executeQuery(query);
                 if(rs.next()){
                     flightcode.setText(rs.getString("FLIGHT_CODE"));
                    FLIGHT_NUMBER.setText(rs.getString("FLIGHT_NAME"));
                    dtime.setText(rs.getString("DEPARTURETIME"));
                    atime.setText(rs.getString("ARRIVAL_TIME"));
                     
     
                
             }else {
                 JOptionPane.showMessageDialog(rootPane, "NO FLIGHT EXIST");
             }                                                                     
    }
    catch(Exception e){
                e.printStackTrace();
              
    }   
   }
    }//GEN-LAST:event_searchFlightActionPerformed

    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneActionPerformed

    private void bookFlightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookFlightActionPerformed
       if(evt.getSource()==bookFlight){
      Random random=new Random();
           String nic1 = nic.getText();
       String name1 = name.getText();
      String nationality1 = nationality.getText();
      String phone1 = phone.getText();
      String address1 = address.getText();
      String gender1 = gender.getText();
      String filghtname =  FLIGHT_NUMBER.getText();
      String filghtcode =  flightcode.getText();
      String src =  source.getSelectedItem();
        String dest =  destination.getSelectedItem();
        String ddate=((JTextField)dcdate.getDateEditor().getUiComponent()).getText();
        String departtime=dtime.getText();
        String arrivetime=atime.getText();
      
       try {
                connection c = new connection();
                String query = "insert into reservation values('PNR-"+random.nextInt(100000)+"' , 'Tic-"+random.nextInt(10000)+"','"+nic1+"', '"+name1+"','"+nationality1+"', '"+phone1+"', '"+address1+"','"+gender1+"', '"+filghtname+"','"+filghtcode+"','"+src+"','"+dest+"','"+ddate+"','"+departtime+"','"+arrivetime+"')";
                c.s.executeUpdate(query);
           JOptionPane.showMessageDialog(rootPane, "FLIGHT TICKET BOOK SUCCESSFULLY");
           setVisible(false);
    allinfo a1=new allinfo();
      a1.setVisible(true);
      a1.pack();
      a1.setLocationRelativeTo(null); 
      this.dispose();
                       
                                                                 
    }
    catch(Exception e){
                e.printStackTrace();
                
               
    }
}
       else {
                 JOptionPane.showMessageDialog(rootPane, "WORNG INFORMATION");
             }            
    
    }//GEN-LAST:event_bookFlightActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(flightbooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(flightbooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(flightbooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(flightbooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new flightbooking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField FLIGHT_NUMBER;
    private javax.swing.JTextField address;
    private javax.swing.JTextField atime;
    private javax.swing.JButton bookFlight;
    private javax.swing.ButtonGroup buttonGroup1;
    private java.awt.Choice destination;
    private javax.swing.JTextField dtime;
    private javax.swing.JLabel flightCode;
    private javax.swing.JTextField flightcode;
    private javax.swing.JLabel flightnumber;
    private javax.swing.JTextField gender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jdatechosser;
    private javax.swing.JLabel jlable1;
    private javax.swing.JLabel jlable2;
    private javax.swing.JLabel jlable3;
    private javax.swing.JLabel jlable4;
    private javax.swing.JLabel jlable6;
    private javax.swing.JTextField name;
    private javax.swing.JTextField nationality;
    private javax.swing.JTextField nic;
    private javax.swing.JTextField phone;
    private javax.swing.JButton search;
    private javax.swing.JButton searchFlight;
    private java.awt.Choice source;
    // End of variables declaration//GEN-END:variables
}
